package com.asesinosdesoftware.javeparking.controller;

import com.asesinosdesoftware.javeparking.entities.Parqueadero;

public class ReportesController {

    private Parqueadero parqueadero;
}
