package com.asesinosdesoftware.javeparking.controller;

public class MenuAdminViewController {
}
