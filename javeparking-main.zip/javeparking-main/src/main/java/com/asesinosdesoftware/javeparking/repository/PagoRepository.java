package com.asesinosdesoftware.javeparking.repository;

public class PagoRepository {
}
