package com.asesinosdesoftware.javeparking.controller;

import com.asesinosdesoftware.javeparking.entities.Pago;

public class PagoController {

    private Pago pago;
}
