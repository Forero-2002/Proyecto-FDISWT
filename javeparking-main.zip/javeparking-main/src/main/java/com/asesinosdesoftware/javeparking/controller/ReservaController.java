package com.asesinosdesoftware.javeparking.controller;

import com.asesinosdesoftware.javeparking.entities.Reserva;

public class ReservaController {

    private Reserva reserva;
}
